#!/usr/bin/env python
import argparse
import sys
import codecs
if sys.version_info[0] == 2:
  from itertools import izip
else:
  izip = zip
from collections import defaultdict as dd
import re
import os.path
import gzip
import tempfile
import shutil
import atexit

# Use word_tokenize to split raw text into words
from string import punctuation

import nltk
from nltk.tokenize import word_tokenize

scriptdir = os.path.dirname(os.path.abspath(__file__))

reader = codecs.getreader('utf8')
writer = codecs.getwriter('utf8')

def prepfile(fh, code):
  if type(fh) is str:
    fh = open(fh, code)
  ret = gzip.open(fh.name, code if code.endswith("t") else code+"t") if fh.name.endswith(".gz") else fh
  if sys.version_info[0] == 2:
    if code.startswith('r'):
      ret = reader(fh)
    elif code.startswith('w'):
      ret = writer(fh)
    else:
      sys.stderr.write("I didn't understand code "+code+"\n")
      sys.exit(1)
  return ret

def addonoffarg(parser, arg, dest=None, default=True, help="TODO"):
  ''' add the switches --arg and --no-arg that set parser.arg to true/false, respectively'''
  group = parser.add_mutually_exclusive_group()
  dest = arg if dest is None else dest
  group.add_argument('--%s' % arg, dest=dest, action='store_true', default=default, help=help)
  group.add_argument('--no-%s' % arg, dest=dest, action='store_false', default=default, help="See --%s" % arg)



class LimerickDetector:

    def __init__(self):
        """
        Initializes the object to have a pronunciation dictionary available
        """
        self._pronunciations = nltk.corpus.cmudict.dict()

        ## This is a set for all consonant
        self.consonant = set(['P','B','T','D','K','G','CH','JH','F','V','TH','DH','S','Z','SH','ZH','HH','M','EM','N','EN','NG','ENG','L','EL','R','DX','NX','Y','W','Q'])


    def num_syllables(self, word):
        """
        Returns the number of syllables in a word.  If there's more than one
        pronunciation, take the shorter one.  If there is no entry in the
        dictionary, return 1.
        """

        # TODO: provide an implementation!

        number=0
        if word=="":
            return 1
        if word in self._pronunciations.keys():

            pronunciations = self._pronunciations[word]
            location = 0

            length = float('inf')

            for index in range(0,len(pronunciations)):
                if len(pronunciations[index])<length:
                    length = len(pronunciations[index])
                    location = index
            listOfpro = pronunciations[location]
            number=0
            for elements in listOfpro:
                if elements in self.consonant:
                    number+=1
            numberofsyllables = len(listOfpro)-number


            return numberofsyllables

        else:
            return 1


    def rhymes(self, a, b):
        """
        Returns True if two words (represented as lower-case strings) rhyme,
        False otherwise.
        """

        # TODO: provide an implementation!

        # lowercase
        a = a.lower()
        b = b.lower()

        # if a is not in the dictionary
        if a not in self._pronunciations.keys():
            return False
        # if b is not in the dictionary
        if b not in self._pronunciations.keys():
            return False



        # get the pronunciation of word a
        pronunciationsA = self._pronunciations[a]


        # get the pronunciation of word b
        pronunciationsB = self._pronunciations[b]

        AisAllVowel = True
        BisAllVowel = True

        numA=0
        numB=0

        ## This is the first method, original defination
        for proA in pronunciationsA:
            for proB in pronunciationsB:



                # Check the location of the first vowel in A
                locationA = -1
                for index in range(len(proA)):
                    if proA[index] not in self.consonant:
                        locationA = index
                        AisAllVowel = False
                        break

                # Check the location of the first vowel in B

                locationB = -1
                for index in range(len(proB)):
                    if proB[index] not in self.consonant:
                        locationB = index
                        BisAllVowel = False
                        break

                # # Situation1, A and B are all vowel word
                # if len(proA)==locationA+1 and len(proB)==locationB+1 :
                #     subproA=proA[:]
                #     subproB=proB[:]
                # # Situation2, A and B are both not all vowel
                # if len(proA)!=locationA+1 and len(proB)!=locationB+1:
                #     subproA = proA[locationA:]
                #     subproB = proB[locationB:]
                # # Situation3, A is not
                # if len(proA)!=locationA+1 and len(proB)==locationB+1:
                #     subproA = proA[locationA:]
                #     subproB = proB[:]
                # # Situation4, B is not
                # if len(proA) == locationA + 1 and len(proB) != locationB + 1:
                #     subproA = proA[:]
                #     subproB = proB[locationB:]


                subproA = proA[locationA:]
                subproB = proB[locationB:]

                # When you get subproA and subproB,
                # 1, same length, should exactly the same
                if len(subproA) == len(subproB):
                    if subproA == subproB:
                        return True
                # 2, A > B, B should be a suffix of A
                if len(subproA) > len(subproB):
                    ok = True
                    for index in range(-len(subproB), 0):
                        if subproB[index] != subproA[index]:
                            ok = False
                    if ok == True:
                        return True
                # 3, B > A, A should be a suffix of B
                if len(subproA) < len(subproB):
                    ok = True
                    for index in range(-len(subproA), 0):
                        if subproB[index] != subproA[index]:
                            ok = False
                    if ok == True:
                        return True


        return False



        ## This is the second method, alternative defination
        # for proA in pronunciationsA:
        #     for proB in pronunciationsB:
        #
        #
        #
        #         # if all sounds are vowel in A, check the location of the first consonant
        #         locationA = -1
        #         for index in range(len(proA)):
        #             if proA[index] in self.consonant:
        #                 locationA = index
        #                 AisAllVowel = False
        #                 break
        #
        #         # if all sounds are vowel in B, check the location of the first consonant in B
        #
        #         locationB = -1
        #         for index in range(len(proB)):
        #             if proB[index] in self.consonant:
        #                 locationB = index
        #                 BisAllVowel = False
        #                 break
        #
        #         # Situation1, if A and B are both not exclusive vowel
        #         if AisAllVowel==False and BisAllVowel==False:
        #             # subproA = proA[locationA + 1:]  ## Wether location should +1 ??????
        #             # subproB = proB[locationB + 1:]  ## Wether location should +1 ??????
        #
        #             if len(proA[locationA+1:]) != 0 :
        #                 subproA = proA[locationA+1:]      ## Wether location should +1 ??????
        #             else:
        #                 subproA = proA[:]
        #             if len(proB[locationB + 1:]) != 0:
        #                 subproB = proB[locationB+1:]      ## Wether location should +1 ??????
        #             else:
        #                 subproB = proB[:]
        #
        #
        #         # Situation2, if A is all Vowel, A should be a suffix of B
        #         if AisAllVowel==True and BisAllVowel==False:
        #             # subproB = proB[locationB+1:]      ## Wether location should +1 ??????
        #             # subproA = proA[:]
        #
        #             if len(proB[locationB + 1:]) != 0:
        #                 subproB = proB[locationB+1:]      ## Wether location should +1 ??????
        #             else:
        #                 subproB = proB[:]
        #             subproA = proA[:]
        #
        #
        #         # Situation3, if B is all Vowel, B should be a suffix of A
        #         if BisAllVowel==True and AisAllVowel==False:
        #             # subproA = proA[locationA+1:]      ## Wether location should +1 ??????
        #             # subproB = proB[:]
        #             if len(proA[locationA+1:]) != 0 :
        #                 subproA = proA[locationA+1:]      ## Wether location should +1 ??????
        #             else:
        #                 subproA = proA[:]
        #             subproB = proB[:]
        #
        #
        #         # Situation4, if A is all Vowel, B is also all Vowel
        #         if BisAllVowel==True and AisAllVowel==True:
        #             subproA = proA[:]  ## Wether location should +1 ??????
        #             subproB = proB[:]
        #
        #         #print "1", proA, proB, subproA, subproB, locationA, locationB
        #
        #
        #         # When you get subproA and subproB,
        #         # 1, same length, should exactly the same
        #         if len(subproA) == len(subproB):
        #             if subproA == subproB:
        #                 return True
        #         # 2, A > B, B should be a suffix of A
        #         if len(subproA) > len(subproB):
        #             ok = True
        #             for index in range(-len(subproB), 0):
        #                 if subproB[index] != subproA[index]:
        #                     ok = False
        #             if ok == True:
        #                 return True
        #         # 3, B > A, A should be a suffix of B
        #         if len(subproA) < len(subproB):
        #             ok = True
        #             for index in range(-len(subproA), 0):
        #                 if subproB[index] != subproA[index]:
        #                     ok = False
        #             if ok == True:
        #                 return True
        #
        #
        # return False

    def is_limerick(self, text):
        """
        Takes text where lines are separated by newline characters.  Returns
        True if the text is a limerick, False otherwise.

        A limerick is defined as a poem with the form AABBA, where the A lines
        rhyme with each other, the B lines rhyme with each other, and the A lines do not
        rhyme with the B lines.


        Additionally, the following syllable constraints should be observed:
          * No two A lines should differ in their number of syllables by more than two.
          * The B lines should differ in their number of syllables by no more than two.
          * Each of the B lines should have fewer syllables than each of the A lines.
          * No line should have fewer than 4 syllables

        (English professors may disagree with this definition, but that's what
        we're using here.)


        """
        # TODO: provide an implementation!

        # Delete "." "," ":" and so on

        for c in punctuation:
            if c != "'":
                text = text.replace(c,"")

        lines= text.strip().split("\n")


        #print lines

        # split lines into words using space
        linesWithSplitedWord = []
        for line in lines:
            # delete empty line
            if line != "":
                linesWithSplitedWord.append(word_tokenize(line))
            #linesWithSplitedWord.append(line.strip().split(" "))
        #print linesWithSplitedWord


        syllableList = []
        # count the syllable:
        for i in range(len(linesWithSplitedWord)):
            lineSyllable = 0
            for j in range(len(linesWithSplitedWord[i])):
                lineSyllable = lineSyllable + self.num_syllables(linesWithSplitedWord[i][j])

            syllableList.append(lineSyllable)
            # Additionally, Rule #4, No line should have fewer than 4 syllables:
            if lineSyllable < 4:
                #print "1"
                return False

        #print syllableList



        # Rule #0, if this poem is not 5 lines, return false.
        if len(syllableList)!=5:
            #print "2"
            return False
        #print syllableList[0], syllableList[1], syllableList[2], syllableList[3], syllableList[4]
        # Additionally, Rule #1, No two A lines should differ in their number of syllables by more than two.:

        if abs(syllableList[0]-syllableList[1]) > 2 or abs(syllableList[0]-syllableList[4]) > 2 or abs(syllableList[1]-syllableList[4]) > 2 :

            #print "3"
            return False

        # Additionally, Rule #2, The B lines should differ in their number of syllables by no more than two.:
        if abs(syllableList[2]-syllableList[3]) > 2 :

            #print "4"
            return False

        # Additionally, Rule #3, Each of the B lines should have fewer syllables than each of the A lines.:
        if syllableList[2] >= syllableList[0] or syllableList[2] >= syllableList[1] or syllableList[2] >= syllableList[4]:
            #print "5"
            return False

        if syllableList[3] >= syllableList[0] or syllableList[3] >= syllableList[1] or syllableList[3] >= syllableList[4]:
            #print "6"
            return False




        # Check the rythme for A lines
        if self.rhymes(linesWithSplitedWord[0][-1],linesWithSplitedWord[1][-1]) == False or\
            self.rhymes(linesWithSplitedWord[0][-1], linesWithSplitedWord[4][-1]) == False or\
            self.rhymes(linesWithSplitedWord[1][-1],linesWithSplitedWord[4][-1]) == False:
            #print "7"
            return False


        # Check the rythme for B lines
        if self.rhymes(linesWithSplitedWord[2][-1],linesWithSplitedWord[3][-1]) == False:
            #print "8"
            return False


        # Check the rythme for A,B lines
        if self.rhymes(linesWithSplitedWord[0][-1],linesWithSplitedWord[2][-1]) == True or \
            self.rhymes(linesWithSplitedWord[1][-1], linesWithSplitedWord[2][-1]) == True or \
            self.rhymes(linesWithSplitedWord[4][-1], linesWithSplitedWord[2][-1]) == True:
            print linesWithSplitedWord[4][-1],linesWithSplitedWord[2][-1],self.rhymes(linesWithSplitedWord[4][-1],linesWithSplitedWord[2][-1])
            #print "9"
            return False

        if self.rhymes(linesWithSplitedWord[0][-1],linesWithSplitedWord[3][-1]) == True or \
            self.rhymes(linesWithSplitedWord[1][-1], linesWithSplitedWord[3][-1]) == True or \
            self.rhymes(linesWithSplitedWord[4][-1], linesWithSplitedWord[3][-1]) == True:
            #print "10"
            return False


        return True


    # Write my function : apostrophe_tokenize
    def apostrophe_tokenize(self, line):
        tokenList = word_tokenize(line)
        #tokenList=line.strip().split(" ")
        length = len(tokenList)
        location = []
        #print tokenList

        for i in range(length):
            if "'" in tokenList[i]:
                tokenList[i]= tokenList[i-1] + tokenList[i]
                location.append(i-1)


        tokenList = [x for i, x in enumerate(tokenList) if i not in location]

        #print tokenList
        return tokenList

    # Write my function : guess_syllables
    def guess_syllables(self, word):
        number = 0
        word = word.lower()
        vowelWordSedt = ['a','e','i','o','u']
        singleSet = ['a','e','i','o','u','y']
        doubleSet = ['ar','ai','ay','al','as','aw','ea','ee','ir','or','oa','oo','ou','ow','ur','ue']
        trebleSet = ['air','all','ass','ere','ear','igh','eye']

        # treble count
        for index in range(len(word)):
            # if we can find next sequential 3-letters,
            if index + 3 <= len(word):
                # if it is in the treble set
                if word[index:index + 3] in trebleSet:
                    number = number + 1
                    word = word.replace(word[index:index + 3], "")
                    index = index - 1
            # if we can not find next sequential 3-letters
            else:
                break


        # deal with the silence "e"
        if word != "":
            if word[-1]=='e' and word[-2] not in vowelWordSedt and word[-3] in vowelWordSedt:
                word = word[:-1]



        # double count
        for index in range(len(word)):
            # if we can find next sequential 2-letters,
            if index + 2 <= len(word):
                # if it is in the treble set
                if word[index:index + 2] in doubleSet:
                    number = number + 1
                    word = word.replace(word[index:index + 2], "")
                    index = index - 1
            # if we can not find next sequential 2-letters
            else:
                break


        # single count
        for index in range(len(word)):
            #print word
            # if we can find next sequential 3-letters,
            if word[index] in singleSet:
                    number = number + 1

        return number

# The code below should not need to be modified
def main():
  parser = argparse.ArgumentParser(description="limerick detector. Given a file containing a poem, indicate whether that poem is a limerick or not",
                                   formatter_class=argparse.ArgumentDefaultsHelpFormatter)
  addonoffarg(parser, 'debug', help="debug mode", default=False)
  parser.add_argument("--infile", "-i", nargs='?', type=argparse.FileType('r'), default=sys.stdin, help="input file")
  parser.add_argument("--outfile", "-o", nargs='?', type=argparse.FileType('w'), default=sys.stdout, help="output file")




  try:
    args = parser.parse_args()
  except IOError as msg:
    parser.error(str(msg))

  infile = prepfile(args.infile, 'r')
  outfile = prepfile(args.outfile, 'w')

  ld = LimerickDetector()
  lines = ''.join(infile.readlines())
  outfile.write("{}\n-----------\n{}\n".format(lines.strip(), ld.is_limerick(lines)))

if __name__ == '__main__':
  main()
