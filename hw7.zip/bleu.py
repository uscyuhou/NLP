from __future__ import division

import math

def count_ngram(hypothesis, reference, n):
    number_correct = 0
    count = 0


    ref_lengths = 0




    # Build dictionary of ngram counts

    ref_sentence = reference
    ngram_dict = {}
    words = ref_sentence.strip().split()

    ref_lengths=len(words)

    limits = len(words) - n + 1
    # loop through the sentance consider the ngram length

    for i in range(limits):
        ngram = ' '.join(words[i:i+n]).lower()
        if ngram in ngram_dict.keys():
            ngram_dict[ngram] += 1
        else:
            ngram_dict[ngram] = 1

    ref_counts=ngram_dict

    if limits < 0:
        countprime = 0
    else:
        countprime = limits


    # hypothesis
    hyp_sentence = hypothesis
    hyp_dict = {}

    words = hyp_sentence.strip().split()

    limits = len(words) - n + 1
    for i in range(0, limits):
        ngram = ' '.join(words[i:i + n]).lower()
        if ngram in hyp_dict:
            hyp_dict[ngram] += 1
        else:
            hyp_dict[ngram] = 1


    number_correct += correct_count(hyp_dict, ref_counts)

    # count = limits
    # cannot give limits to count directly, because of below zero??????
    if limits < 0:
        count = 0
    else:
        count = limits





    # if number_correct == 0:
    #     pr = (float(number_correct) + float(n)) / (count + float(n))
    # else:
    pr1 = (float(number_correct) + float(n)) / (count + float(n))
    pr2 = (float(number_correct) + float(n)) / (countprime + float(n))

    alpha = 0.1
    fenmu = ((1 - alpha) * pr1 + alpha * pr2)
    pr = (pr1 * pr2) / fenmu

    return pr


def correct_count(hyp_d, ref_dictionary):
    #Count the correct count for each ngram

    count = 0
    for m in hyp_d.keys():
        m_w = hyp_d[m]
        m_max = 0

        if m in ref_dictionary:
            m_max = max(m_max, ref_dictionary[m])


        m_w = min(m_w, m_max)
        count += m_w
    return count


def best_length_match(ref_l, hyp_l):
    #Find the closest length of reference to that of hypothesis
    
    least_diff = abs(hyp_l-ref_l)
    best = ref_l


    if abs(hyp_l-ref_l) < least_diff:
        least_diff = abs(hyp_l-ref_l)
        best = ref_l

    return best


def penalty(c, r):
    if c > r:
        bp = 1
    else:
        bp = math.exp(1-(float(r)/c))
    return bp


def geometric_mean_as_P(p_value):
    value = 1.0
    for index in range(len(p_value)):
        value =  value * p_value[index]

    returnvalue = value ** (1.0 / len(p_value))

    return returnvalue



def BLEU(hypothesis, reference):


    p_value = []
    for i in range(4):
        pr = count_ngram(hypothesis, reference, i+1)
        p_value.append(pr)
    c = len(hypothesis.strip().split())
    r = len(reference.strip().split())

    bp = penalty(c,r)
    bleu = geometric_mean_as_P(p_value) * bp
    # print bleu
    return bleu

if __name__ == "__main__":
    hypothesis = "Republican leaders justify its policy necessary to combat electoral fraud."
    reference = "Republican leaders justified their policy by the need to combat electoral fraud."
    bleu = BLEU(hypothesis, reference)
    print bleu

