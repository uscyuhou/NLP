import sys, fileinput
import tree


dictTotal = {}
for line in fileinput.input(sys.argv[1]):
    #print line

    t = tree.Tree.from_str(line)

    #dictParse = {}

    ## recursive method to get the rules:
    def dictGenerate(root):

        list = []
        if root.children != []:
            for node in root.children:
                list.append(node.label)
                dictGenerate(node)

            txt = ""
            for value in list:
                txt = txt + value + " "
            # print txt

            if txt!="<unk>":
                if root.label in dictTotal.keys():
                    if root.label + " -> " + txt in dictTotal[root.label].keys():
                        dictTotal[root.label][root.label + " -> " + txt] += 1
                    else:
                        dictTotal[root.label][root.label + " -> " + txt] = 1
                else:
                    dictTotal[root.label] = {}
                    dictTotal[root.label][root.label + " -> " + txt] = 1
            else:
                if root.label in dictTotal.keys():
                    if root.label + " -> " + txt in dictTotal[root.label].keys():
                        dictTotal[root.label][root.label + " -> " + txt] += 0.3
                    else:
                        dictTotal[root.label][root.label + " -> " + txt] = 0.3
                else:
                    dictTotal[root.label] = {}
                    dictTotal[root.label][root.label + " -> " + txt] = 0.3




    ## deal with the root
    listRoot = []
    #childrenRoot = list(t.root.children)

    for child in t.root.children:
        listRoot.append(child.label)

        ## deal with the children of children
        dictGenerate(child)
    txt=""
    for value in listRoot:
        txt = txt + value + " "

    #dictParse[t.root.label] = {}
    if t.root.label in dictTotal.keys():
        if t.root.label + " -> " + txt in dictTotal[t.root.label].keys():
            dictTotal[t.root.label][t.root.label + " -> " + txt] += 1
        else:
            dictTotal[t.root.label][t.root.label + " -> " + txt] = 1
    else:
        dictTotal[t.root.label] = {}
        dictTotal[t.root.label][t.root.label + " -> " + txt] = 1

    totalRule = 0
    for element in dictTotal:
        thisNumber = 0
        totalRule += len(dictTotal[element].keys())










# print dictTotal

## Additional rules I added:
for element in dictTotal:
    if element in ["TOP"]:
        dictTotal[element][element+" -> "+"<unk> <unk>"]=1
    if element == "POS":
        dictTotal["VBZ"]["VBZ"+" -> " + "'s"] = 1



# print dictTotal


#####################
# Getting the occurence, can be noted:

with open("my.grammar.occurrence", 'w') as f:
    for element in dictTotal:
       for key in dictTotal[element].keys():
            f.write(key + "# "+ str(dictTotal[element][key]) + "\n")

dictTotalFrequency = dict(dictTotal)
totalRule=0
for element in dictTotal:
    thisNumber=0
    totalRule += len(dictTotal[element].keys())
    for key in dictTotal[element].keys():
        thisNumber += dictTotal[element][key]
    for key in dictTotal[element].keys():
        dictTotalFrequency[element][key] = round(float(dictTotalFrequency[element][key])/float(thisNumber),5)


# print len(dictTotal.keys())
# print totalRule




########################
with open("my.grammar.frequency", 'w') as f:
    for element in dictTotalFrequency:
       for key in dictTotalFrequency[element].keys():
            f.write(key + "# "+ str(dictTotalFrequency[element][key]) + "\n")



## normalize rules:

with open("my.grammar.frequency", 'r') as f:
    lines=f.readlines()

with open("my.grammar.frequency.normal", 'w') as f:
    f.write("lhs"+"\t"+"rhs"+"\t"+"probability" + "\n")
    for line in lines:
        probability=""
        lhs=""
        rhs=""
        list1=line.strip().split("#")


        probability=list1[1].strip()
        list2=list1[0].strip().split("->")

        lhs=list2[0].strip()
        rhs=list2[1].strip()
        f.writelines(lhs+"\t"+rhs+"\t"+probability+"\n")


