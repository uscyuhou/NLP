from csv import DictReader,DictWriter
from math import log
import time
import sys, fileinput




## use dictionary reader to read grammar
file = open("my.grammar.frequency.normal", 'r')
grammar = DictReader(file, delimiter='\t')
## create a index
indexGrammar = {}
for ii in grammar: #make reverse lookup
    #print ii['probability']
    if ii['rhs'] in indexGrammar.keys():
        if ii['lhs'] in indexGrammar[ii['rhs']].keys() :
            print "1"
        else:
            indexGrammar[ii['rhs']][ii['lhs']] = ii['probability']
    else:
        indexGrammar[ii['rhs']] = {}
        indexGrammar[ii['rhs']][ii['lhs']] = ii['probability']

#print indexGrammar

#########
# For getting the initial case:
#########

def init_matrix(tokens, indexGrammar):
    numtokens = len(tokens)
    # fill w/ water full matrix
    matrix = [["~" for i in range(numtokens+1)]
              for j in   range(numtokens+1)]
    # fill in diagonal
    for i in range(numtokens):
        fillIn = {}
        if tokens[i] not in indexGrammar.keys():
            dictionary = indexGrammar["<unk>"]
            for key in dictionary.keys():
                fillIn[key]=[tokens[i],round(log(float(dictionary[key])),5),'K']
        else:
            dictionary = indexGrammar[tokens[i]]
            for key in dictionary.keys():
                fillIn[key] = [tokens[i], round(log(float(dictionary[key])),5), 'K']

        # #print fillIn
        matrix[i][i+1] = fillIn
    return matrix

############
## fill in the table, getting other cases:
############

def complete_matrix(matrix, tokens, indexGrammar):

    numtokens = len(tokens)
    #print numtokens
    for span in range(2, numtokens+1):

        # print span
        for start in range(numtokens+1-span): #go down diagonal
            end = start + span
            #print range(start+1,end)
            for mid in range(start+1, end):

                nt1, nt2 = matrix[start][mid], matrix[mid][end]
                if nt1 != "~" and nt2 != "~":
                    for element1 in nt1.keys():
                        for element2 in nt2.keys():
                            rhsHere=element1+" "+element2

                            ## If it in the grammar dictionary:
                            if rhsHere in indexGrammar:


                                ## It it the first time to fill in this cell
                                if matrix[start][end] == "~":
                                    matrix[start][end] = {}
                                    dictHere = indexGrammar[rhsHere]
                                    for lhsHere in dictHere.keys():

                                        ## delete TOP in other cells:
                                        if lhsHere!= "TOP" or (lhsHere =="TOP" and start==0 and end==numtokens) :

                                            # This lhs occur first time:
                                            if lhsHere not in matrix[start][end].keys():


                                                #print nt1
                                                probability = round(log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(nt2[element2][1]),5)
                                                matrix[start][end][lhsHere] = [[element1,element2], probability, mid]


                                            else:


                                                probability = round(log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(nt2[element2][1]),5)
                                                # compare two probability. What if equals?????
                                                if probability > matrix[start][end][lhsHere][1]:
                                                    matrix[start][end][lhsHere] = [[element1,element2], probability, mid]


                                ## Tt is not the first time to fill in this cell
                                else:
                                    dictHere = indexGrammar[rhsHere]
                                    for lhsHere in dictHere.keys():


                                        if lhsHere!= "TOP" :


                                            # This lhs occur first time:
                                            if lhsHere not in matrix[start][end].keys():

                                                #print nt1
                                                probability = round(log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(nt2[element2][1]), 5)
                                                matrix[start][end][lhsHere] = [[element1,element2], probability, mid]


                                            else:
                                                # print "@@@@"
                                                # print nt1
                                                # print "####"
                                                # print nt2

                                                probability = round(log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(nt2[element2][1]), 5)
                                                # compare two probability. What if equals?????
                                                if probability > matrix[start][end][lhsHere][1]:
                                                    matrix[start][end][lhsHere] = [[element1,element2], probability, mid]
                                        else:

                                            if start == 0 and end == numtokens:
                                                # This lhs occur first time:
                                                if lhsHere not in matrix[start][end].keys():

                                                    # print nt1
                                                    probability = round(
                                                        log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                            nt2[element2][1]), 5)
                                                    matrix[start][end][lhsHere] = [[element1, element2], probability,
                                                                                   mid]


                                                else:
                                                    # print "@@@@"
                                                    # print nt1
                                                    # print "####"
                                                    # print nt2

                                                    probability = round(
                                                        log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                            nt2[element2][1]), 5)
                                                    # compare two probability. What if equals?????
                                                    if probability > matrix[start][end][lhsHere][1]:
                                                        matrix[start][end][lhsHere] = [[element1, element2],
                                                                                       probability, mid]




                            ## If it not in the grammar dictionary
                            ## Create a situation that two words can be parsed to any label
                            else:
                                rhsHere="<unk> <unk>"
                                if matrix[start][end] == "~":
                                    matrix[start][end] = {}
                                    dictHere = indexGrammar[rhsHere]
                                    for lhsHere in dictHere.keys():

                                        ## delete TOP in other cells:
                                        if lhsHere != "TOP" :

                                            # This lhs occur first time:
                                            if lhsHere not in matrix[start][end].keys():

                                                # print nt1
                                                probability = round(
                                                    log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                        nt2[element2][1]), 5)
                                                matrix[start][end][lhsHere] = [[element1, element2], probability, mid]


                                            else:

                                                probability = round(
                                                    log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                        nt2[element2][1]), 5)
                                                # compare two probability. What if equals?????
                                                if probability > matrix[start][end][lhsHere][1]:
                                                    matrix[start][end][lhsHere] = [[element1, element2], probability,
                                                                                   mid]
                                        else:
                                             if start == 0 and end == numtokens:
                                                 # This lhs occur first time:
                                                 if lhsHere not in matrix[start][end].keys():

                                                     # print nt1
                                                     probability = round(
                                                         log(float(dictHere[lhsHere])) + float(
                                                             nt1[element1][1]) + float(
                                                             nt2[element2][1]), 5)
                                                     matrix[start][end][lhsHere] = [[element1, element2], probability,
                                                                                    mid]


                                                 else:

                                                     probability = round(
                                                         log(float(dictHere[lhsHere])) + float(
                                                             nt1[element1][1]) + float(
                                                             nt2[element2][1]), 5)
                                                     # compare two probability. What if equals?????
                                                     if probability > matrix[start][end][lhsHere][1]:
                                                         matrix[start][end][lhsHere] = [[element1, element2],
                                                                                        probability,
                                                                                        mid]



                                ## it is not the first time to fill this cell
                                else:
                                    dictHere = indexGrammar[rhsHere]
                                    for lhsHere in dictHere.keys():

                                        if lhsHere != "TOP" or (lhsHere == "TOP" and start == 0 and end == numtokens) :

                                            # This lhs occur first time:
                                            if lhsHere not in matrix[start][end].keys():

                                                # print nt1
                                                probability = round(
                                                    log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                        nt2[element2][1]), 5)
                                                matrix[start][end][lhsHere] = [[element1, element2], probability, mid]


                                            else:
                                                # print "@@@@"
                                                # print nt1
                                                # print "####"
                                                # print nt2

                                                probability = round(
                                                    log(float(dictHere[lhsHere])) + float(nt1[element1][1]) + float(
                                                        nt2[element2][1]), 5)
                                                # compare two probability. What if equals?????
                                                if probability > matrix[start][end][lhsHere][1]:
                                                    matrix[start][end][lhsHere] = [[element1, element2], probability,
                                                                                   mid]


                                                    #print matrix[start][end]

    return matrix

## display
def display(matrix, tokens):
    print '\nParseMatrix ' + '\t\t\t\t\t\t\t'.join([("%-4d" % i) for i in range(1, len(matrix))])
    for i in range(len(matrix)-1):
        print "%-4s " % i,
        for j in range(1, len(matrix)):
           print "%-10s" % matrix[i][j] +"\t\t",
        print "\n""\n"




lines = fileinput.input(sys.argv[1])



timeVSlength=[]


## for storing the results
with open("dev.parses", 'w') as f:

    #print lines
    for s in lines:
        start_time=time.time()
        slength = len(s)

        tokens = s.replace("\n","").split(" ")
        # get initial
        matrix0 = init_matrix(tokens, indexGrammar)
        # get new case
        matrix1 = complete_matrix(matrix0,tokens,indexGrammar)
        # display(matrix1, tokens)


        ## use a DFS to get the tree
        # DFS
        import Queue


        expand = Queue.Queue()
        generate = Queue.Queue()

        goal = False  # whether find the goal

        # print type([]) is list

        numtokens = len(tokens)

        dictionary = matrix1[0][numtokens]
        # print dictionary
        if dictionary=="~" or "TOP" not in dictionary.keys():
            s=" "
        else:
            logProb=float(dictionary["TOP"][1])



            # Insert with the numbers for convenience:

            s="TOP"+"0"+str(numtokens)
            optNode = ["TOP",[0,numtokens]]
            generate.put(optNode)

            while goal==False:
                newNode=generate.get()
                #print newNode
                expand.put(newNode)
                # for element in matrix1[newNode[1][0]][newNode[1][1]][newNode[0]][0]:
                start=newNode[1][0]
                mid=matrix1[newNode[1][0]][newNode[1][1]][newNode[0]][2]
                end=newNode[1][1]
                elements=matrix1[newNode[1][0]][newNode[1][1]][newNode[0]][0]
                if type(elements) is list:
                    generate.put([elements[0],[start,mid]])
                    generate.put([elements[1],[mid,end]])
                    s=s.replace(newNode[0]+str(newNode[1][0])+str(newNode[1][1]),  "("+ newNode[0]+str(newNode[1][0])+str(newNode[1][1])+" "+elements[0]+str(start)+str(mid)+" "+elements[1]+str(mid)+str(end)+")")
                else:
                    # print "1"
                    s=s.replace(newNode[0]+str(newNode[1][0])+str(newNode[1][1]),  "("+ newNode[0]+str(newNode[1][0])+str(newNode[1][1])+" "+elements+")")

                if generate.empty():

                    goal=True

            for number in range(0,10):
                s=s.replace(str(number),"")

        stime=time.time()-start_time

        ##for dev.parses
        f.writelines(s+"\n")


        ## for time
        timeVSlength.append([slength,stime])

        # ## for log-probability:
        # if s=="":
        #     f.writelines(s+"\n")
        # else:
        #     f.writelines(s +"\t"+str(logProb)+ "\n" )


