#!/usr/bin/env python

import sys, fileinput
import tree
import argparse
import sys
import codecs
if sys.version_info[0] == 2:
  from itertools import izip
else:
  izip = zip
from collections import defaultdict as dd
import re
import os.path
import gzip
import tempfile
import shutil
import atexit

reader = codecs.getreader('utf8')
writer = codecs.getwriter('utf8')


## basic~~~
def prepfile(fh, code):
  if type(fh) is str:
    fh = open(fh, code)
  ret = gzip.open(fh.name, code if code.endswith("t") else code+"t") if fh.name.endswith(".gz") else fh
  if sys.version_info[0] == 2:
    if code.startswith('r'):
      ret = reader(fh)
    elif code.startswith('w'):
      ret = writer(fh)
    else:
      sys.stderr.write("I didn't understand code "+code+"\n")
      sys.exit(1)
  return ret

## prepare
def prepare():
    parser = argparse.ArgumentParser(description="ignore input; make a demo grammar that is compliant in form",
                                   formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # addonoffarg(parser, 'debug', help="debug mode", default=False)
    parser.add_argument("--infile", "-i", nargs='?', type=argparse.FileType('r'), default=sys.stdin,
                      help="input file (ignored)")
    parser.add_argument("--outfile", "-o", nargs='?', type=argparse.FileType('w'), default=sys.stdout,
                      help="output file (grammar)")

    try:
        args = parser.parse_args()
    except IOError as msg:
        parser.error(str(msg))

    workdir = tempfile.mkdtemp(prefix=os.path.basename(__file__), dir=os.getenv('TMPDIR', '/tmp'))

    def cleanwork():
        shutil.rmtree(workdir, ignore_errors=True)

    # if args.debug:
    #     print(workdir)
    # else:
    #     atexit.register(cleanwork)

    infile = prepfile(args.infile, 'r')
    outfile = prepfile(args.outfile, 'w')

    ## main:::

    s=""
    # for line in fileinput.input(sys.argv[1]):
    for line in infile:
          t = tree.Tree.from_str(line)
          if t.root is None:
              s=s+"\n"
              continue
          t.restore_unit()
          t.unbinarize()

          # print t
          # with open("dev.parses.post", 'a') as f:
          s=s+"{0}\n".format(t)


    outfile.write(s)
    outfile.write(workdir)

if __name__ == '__main__':
    prepare()


