#!/usr/bin/env python
import distsim
word_to_vec_dict = distsim.load_word2vec("nyt_word2vec.4k")
# word_to_vec_dict = distsim.load_word2vec("glove.6B/glove.6B.50d.txt")



f = open("word-test.v3.txt","r")
accuracyDict = {}
groupDict = {}
lines = f.readlines()[1:]
f.close()

for line in lines:
    # print line
    elementList = line.strip().split(" ")
    elementListNew=[]
    for element in elementList:
        elementListNew.append(element.strip())
    # print elementListNew

    if elementListNew[0]==":":
        groupDict[elementListNew[1]]=[]
        count = elementListNew[1]
        print count
        example = False

        accuracyDict[count]=[]
    else:
        w1 = word_to_vec_dict[elementListNew[0]]
        w2 = word_to_vec_dict[elementListNew[1]]
        w3 = word_to_vec_dict[elementListNew[2]]
        w4 = word_to_vec_dict[elementListNew[3]]
        ret = distsim.show_nearest(word_to_vec_dict,
                                   w1 - w2 + w4,
                                   set([elementListNew[0], elementListNew[1], elementListNew[3]]),
                                   distsim.cossim_dense)
        right = False

        for i in range(len(ret)):

            if ret[i][0] == elementListNew[2]:

                # if i !=0 and example==False:
                #     print "incorrect predict: "+str(ret[0][0]) + " \t correct answer: "+str(elementListNew[2])
                #     example = True
                # print i
                accuracyDict[count].append(i)
                right =True
                break
        if right == False:
            # print 11
            if example == False:
                print "incorrect predict: "+str(ret[0][0]) + " \t correct answer: "+str(elementListNew[2])
                example = True
            accuracyDict[count].append(11)
#
# print accuracyDict
# print groupDict
# print len(accuracyDict)
# for key in accuracyDict.keys():
#     print len(accuracyDict[key])


## one top

print "one-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 0:
            number1 += 1
    accuracy = float(number1)/float(total)
    groupDict[key].append(accuracy)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)

## five top

print "five-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 4:
            number1 += 1
    accuracy = float(number1)/float(total)
    groupDict[key].append(accuracy)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)


## ten top

print "ten-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 9:
            number1 += 1
    accuracy = float(number1)/float(total)
    groupDict[key].append(accuracy)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)

print groupDict
