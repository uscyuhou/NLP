from __future__ import division
import sys,json,math
import os
import numpy as np

from math import sqrt
from math import exp
from itertools import izip

from operator import itemgetter,attrgetter

def load_word2vec(filename):
    # Returns a dict containing a {word: numpy array for a dense word vector} mapping.
    # It loads everything into memory.
    
    w2vec={}
    with open(filename,"r") as f_in:
        for line in f_in:
            line_split=line.replace("\n","").split()
            w=line_split[0]
            vec=np.array([float(x) for x in line_split[1:]])
            w2vec[w]=vec
    return w2vec

def load_contexts(filename):
    # Returns a dict containing a {word: contextcount} mapping.
    # It loads everything into memory.

    data = {}
    for word,ccdict in stream_contexts(filename):
        data[word] = ccdict
    print "file %s has contexts for %s words" % (filename, len(data))


    return data

def stream_contexts(filename):
    # Streams through (word, countextcount) pairs.
    # Does NOT load everything at once.
    # This is a Python generator, not a normal function.
    for line in open(filename):
        word, n, ccdict = line.split("\t")
        n = int(n)
        ccdict = json.loads(ccdict)
        yield word, ccdict

def cossim_sparse(v1,v2):
    # Take two context-count dictionaries as input
    # and return the cosine similarity between the two vectors.
    # Should return a number beween 0 and 1

    ## TODO: delete this line and implement me

    listv1=[]
    listv2=[]

    keySet= set()

    cossim = 0
    for key in v1.keys():
        keySet.add(key)

    for key in v2.keys():
        keySet.add(key)

    # print len(v1)
    # print len(v2)
    #print len(keySet)

    # change [list] into [set] for fast implementing
    v1keysSet = set(v1.keys())
    v2keysSet = set(v2.keys())
    for key in keySet:


        # Deal with v1
        if key in v1keysSet:
            listv1.append(v1[key])
        else:
            listv1.append(0)

        # Deal with v2
        if key in v2keysSet:
            listv2.append(v2[key])
        else:
            listv2.append(0)
    # print len(listv1)
    # print len(listv2)

    v1v2 = 0
    v1v1 = 0
    v2v2 = 0

    for i in range(len(listv1)):
        v1v2 = v1v2 + listv1[i]*listv2[i]

    for i in range(len(listv1)):
        v1v1 =v1v1 + listv1[i]*listv1[i]

    for i in range(len(listv2)):
        v2v2 =v2v2 + listv2[i]*listv2[i]

    v1v1 = sqrt(v1v1)
    v2v2 = sqrt(v2v2)

    cossim = v1v2 / (v1v1 * v2v2)

    return cossim

def cossim_dense(v1,v2):
    # v1 and v2 are numpy arrays
    # Compute the cosine simlarity between them.
    # Should return a number between -1 and 1
    
    ## TODO: delete this line and implement me

    cossimDense = 0
    # print len(v1)
    # print len(v2)

    # v1v2 = sum(map(lambda x: x[0] * x[1], izip(v1, v2)))
    # v1v1 = sqrt(sum(map(lambda x: x[0] * x[1], izip(v1, v1))))
    # v2v2 = sqrt(sum(map(lambda x: x[0] * x[1], izip(v2, v2))))

    v1v2 = 0
    v1v1 = 0
    v2v2 = 0

    # for i in range(len(v1)):
    #     v1v2 = v1v2 + v1[i] * v2[i]
    #     v1v1 = v1v1 + v1[i] * v1[i]
    #     v2v2 = v2v2 + v2[i] * v2[i]

    v1v1 = np.dot(v1,v1)
    v1v2 = np.dot(v1,v2)
    v2v2 = np.dot(v2,v2)


    # for i in range(len(v1)):
    #     v1v1 =v1v1 + v1[i]*v1[i]
    #
    # for i in range(len(v2)):
    #     v2v2 =v2v2 + v2[i]*v2[i]

    v1v1 = sqrt(v1v1)
    v2v2 = sqrt(v2v2)

    cossimDense = v1v2 / (v1v1 * v2v2)

    return cossimDense


def cossim_denseExp(v1, v2):
    # v1 and v2 are numpy arrays
    # Compute the cosine simlarity between them.
    # Should return a number between -1 and 1

    ## TODO: delete this line and implement me

    cossimDense = 0
    # print v1
    # print v2
    # for i in range(len(v1)):
    #     v1[i] = exp(v1[i]) / (exp(v1[i])+1)
    # for i in range(len(v2)):
    #     v2[i] = exp(v2[i]) / (exp(v2[i])+1)
    for i in range(len(v1)):
        if v1[i] < 0:
            v1[i] = 0
        if v2[i] < 0:
            v2[i] = 0

    # print v1
    # print v2

    # v1v2 = sum(map(lambda x: x[0] * x[1], izip(v1, v2)))
    # v1v1 = sqrt(sum(map(lambda x: x[0] * x[1], izip(v1, v1))))
    # v2v2 = sqrt(sum(map(lambda x: x[0] * x[1], izip(v2, v2))))

    v1v2 = 0
    v1v1 = 0
    v2v2 = 0

    v1v1 = np.dot(v1, v1)
    v1v2 = np.dot(v1, v2)
    v2v2 = np.dot(v2, v2)

    v1v1 = sqrt(v1v1)
    v2v2 = sqrt(v2v2)

    cossimDense = v1v2 / (v1v1 * v2v2)

    return cossimDense

def show_nearest(word_2_vec, w_vec, exclude_w, sim_metric):
    # print word_2_vec
    # print w_vec
    # print exclude_w
    # print sim_metric
    #word_2_vec: a dictionary of word-context vectors. The vector could be a sparse (dictionary) or dense (numpy array).
    #w_vec: the context vector of a particular query word `w`. It could be a sparse vector (dictionary) or dense vector (numpy array).
    #exclude_w: the words you want to exclude in the responses. It is a set in python.
    #sim_metric: the similarity metric you want to use. It is a python function
    # which takes two word vectors as arguments.

    # return: an iterable (e.g. a list) of up to 10 tuples of the form (word, score) where the nth tuple indicates the nth most similar word to the input word and the similarity score of that word and the input word
    # if fewer than 10 words are available the function should return a shorter iterable
    #
    # example:
    #[(cat, 0.827517295965), (university, -0.190753135501)]
    
    ## TODO: delete this line and implement me

    # scoreList=[('cat', 0.827517295965), ('university', -0.190753135501)]
    scoreList = []


    # Method 1:
    for key in word_2_vec.keys():
        #print key
        if key not in exclude_w:
            #print len(word_2_vec[key])
            number = sim_metric( w_vec, word_2_vec[key])
            tupleValue = (key,number)


            insert = False
            for i in range(len(scoreList)):
                if tupleValue[1]>scoreList[i][1]:

                    scoreList.insert(i,tupleValue)
                    if len(scoreList)>10:
                        scoreList.pop()
                    insert = True
                    break
            if insert == False:
                scoreList.append(tupleValue)
                if len(scoreList) > 10:
                    scoreList.pop()
        #print scoreList
        #print len(scoreList)


    # ## Method 2
    # for key in word_2_vec.keys():
    #     if key not in exclude_w:
    #         number = sim_metric(w_vec, word_2_vec[key])
    #         tupleValue = (key, number)
    #
    #         scoreList.append(tupleValue)
    # scoreList=sorted(scoreList,key=lambda element:element[1],reverse=True)


    # ## Methond 3
    # for key in word_2_vec.keys():
    #     #print key
    #     if key not in exclude_w:
    #         #print len(word_2_vec[key])
    #         number = sim_metric( w_vec, word_2_vec[key])
    #         tupleValue = (key,number)
    #
    #
    #         insert = False
    #         if tupleValue[1]>scoreList[len(scoreList)-1][1]:
    #
    #             scoreList.append(tupleValue)
    #             scoreList=sorted(scoreList,key=lambda element:element[1],reverse=True)
    #
    #             if len(scoreList)>10:
    #                 scoreList.pop()
    #                 insert = True
    #
    #         if insert == False:
    #             scoreList.append(tupleValue)
    #             if len(scoreList) > 10:
    #                 scoreList.pop()
    #
    #


    # print scoreList
    return scoreList
