#!/usr/bin/env python
import distsim
word_to_vec_dict = distsim.load_word2vec("nyt_word2vec.4k")


f = open("word-test.v3.forq8.txt","r")
count=0
accuracyDict = {}
for line in f:
    # print line
    elementList = line.strip().split(" ")
    elementListNew=[]
    for element in elementList:
        elementListNew.append(element.strip())
    # print elementListNew
    if elementListNew[0]=="//":
        continue
    if elementListNew[0]==":":
        count+=1
        accuracyDict[count]=[]
    else:
        w1 = word_to_vec_dict[elementListNew[0]]
        w2 = word_to_vec_dict[elementListNew[1]]
        w3 = word_to_vec_dict[elementListNew[2]]
        w4 = word_to_vec_dict[elementListNew[3]]
        ret = distsim.show_nearest(word_to_vec_dict,
                                   w1 - w2 + w4,
                                   set(['king', 'man', 'woman']),
                                   distsim.cossim_dense)
        right = False
        for i in range(len(ret)):

            if ret[i][0] == elementListNew[2]:
                # print i
                accuracyDict[count].append(i)
                right =True
                break
        if right == False:
            # print 11
            accuracyDict[count].append(11)
#
# print accuracyDict
# print len(accuracyDict)
# for key in accuracyDict.keys():
#     print len(accuracyDict[key])

f.close()

## one top

print "one-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 0:
            number1 += 1
    accuracy = float(number1)/float(total)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)

## five top

print "five-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 4:
            number1 += 1
    accuracy = float(number1)/float(total)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)


## ten top

print "ten-top"
for key in accuracyDict.keys():
    total = len(accuracyDict[key])
    number1 = 0
    for element in accuracyDict[key]:
        if element <= 9:
            number1 += 1
    accuracy = float(number1)/float(total)
    print "group #"+str(key)+" accuracy is "+ str(accuracy)