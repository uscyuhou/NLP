#!/usr/bin/env python
import distsim
word_to_vec_dict = distsim.load_word2vec("nyt_word2vec.4k")
###Provide your answer below

###Answer examples
distsim.show_nearest(word_to_vec_dict, word_to_vec_dict['move'],set(['move']),distsim.cossim_dense)
