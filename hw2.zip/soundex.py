from fst import FST
import string, sys
from fsmutils import composechars, trace

def letters_to_numbers():
    """
    Returns an FST that converts letters to numbers as specified by
    the soundex algorithm
    """

    # Let's define our first FST
    f1 = FST('soundex-generate')

    # Indicate that '1' is the initial state
    f1.add_state('start')
    #f1.add_state('next')
    f1.add_state('set0')
    f1.add_state('set1')
    f1.add_state('set2')
    f1.add_state('set3')
    f1.add_state('set4')
    f1.add_state('set5')
    f1.add_state('set6')


    f1.initial_state = 'start'

    # Set all the final states
    #f1.set_final('next')
    f1.set_final('set0')
    f1.set_final('set1')
    f1.set_final('set2')
    f1.set_final('set3')
    f1.set_final('set4')
    f1.set_final('set5')
    f1.set_final('set6')


    # initialize several set:
    set1 = set(['b','f','p','v','B','F','P','V'])
    set2 = set(['c','g','j','k','q','s','x','z','C','G','J','K','Q','S','X','Z'])
    set3 = set(['d', 't','D', 'T'])
    set4 = set(['l','L'])
    set5 = set(['m', 'n','M','N'])
    set6 = set(['r','R'])


    letterCheck = []
    letterCheck = []
    # Add the rest of the arcs
    for letter in string.ascii_letters:

        if letter in set1:
            f1.add_arc('start', 'set1', (letter), (letter))

            #f1.add_arc('next', 'set1', (letter), ('1'))
            f1.add_arc('set0', 'set1', (letter), ('1'))

            f1.add_arc('set2', 'set1', (letter), ('1'))
            f1.add_arc('set3', 'set1', (letter), ('1'))
            f1.add_arc('set4', 'set1', (letter), ('1'))
            f1.add_arc('set5', 'set1', (letter), ('1'))
            f1.add_arc('set6', 'set1', (letter), ('1'))

            f1.add_arc('set1', 'set1', (letter), ())


        elif letter in set2:
            f1.add_arc('start', 'set2', (letter), (letter))

            #f1.add_arc('next', 'set2', (letter), ('2'))
            f1.add_arc('set0', 'set2', (letter), ('2'))

            f1.add_arc('set1', 'set2', (letter), ('2'))
            f1.add_arc('set3', 'set2', (letter), ('2'))
            f1.add_arc('set4', 'set2', (letter), ('2'))
            f1.add_arc('set5', 'set2', (letter), ('2'))
            f1.add_arc('set6', 'set2', (letter), ('2'))

            f1.add_arc('set2', 'set2', (letter), ())

        elif letter in set3:
            f1.add_arc('start', 'set3', (letter), (letter))

            #f1.add_arc('next', 'set3', (letter), ('3'))
            f1.add_arc('set0', 'set3', (letter), ('3'))

            f1.add_arc('set1', 'set3', (letter), ('3'))
            f1.add_arc('set2', 'set3', (letter), ('3'))
            f1.add_arc('set4', 'set3', (letter), ('3'))
            f1.add_arc('set5', 'set3', (letter), ('3'))
            f1.add_arc('set6', 'set3', (letter), ('3'))

            f1.add_arc('set3', 'set3', (letter), ())

        elif letter in set4:
            f1.add_arc('start', 'set4', (letter), (letter))

            #f1.add_arc('next', 'set4', (letter), ('4'))
            f1.add_arc('set0', 'set4', (letter), ('4'))

            f1.add_arc('set1', 'set4', (letter), ('4'))
            f1.add_arc('set2', 'set4', (letter), ('4'))
            f1.add_arc('set3', 'set4', (letter), ('4'))
            f1.add_arc('set5', 'set4', (letter), ('4'))
            f1.add_arc('set6', 'set4', (letter), ('4'))

            f1.add_arc('set4', 'set4', (letter), ())
        elif letter in set5:
            f1.add_arc('start', 'set5', (letter), (letter))

            #f1.add_arc('next', 'set5', (letter), ('5'))
            f1.add_arc('set0', 'set5', (letter), ('5'))

            f1.add_arc('set1', 'set5', (letter), ('5'))
            f1.add_arc('set2', 'set5', (letter), ('5'))
            f1.add_arc('set3', 'set5', (letter), ('5'))
            f1.add_arc('set4', 'set5', (letter), ('5'))
            f1.add_arc('set6', 'set5', (letter), ('5'))

            f1.add_arc('set5', 'set5', (letter), ())
        elif letter in set6:
            f1.add_arc('start', 'set6', (letter), (letter))

            #f1.add_arc('next', 'set6', (letter), ('6'))
            f1.add_arc('set0', 'set6', (letter), ('6'))

            f1.add_arc('set1', 'set6', (letter), ('6'))
            f1.add_arc('set2', 'set6', (letter), ('6'))
            f1.add_arc('set3', 'set6', (letter), ('6'))
            f1.add_arc('set4', 'set6', (letter), ('6'))
            f1.add_arc('set5', 'set6', (letter), ('6'))

            f1.add_arc('set6', 'set6', (letter), ())
        else:
            f1.add_arc('start', 'set0', (letter), (letter))

            #f1.add_arc('next', 'next', (letter), ())
            f1.add_arc('set1', 'set0', (letter), ())
            f1.add_arc('set2', 'set0', (letter), ())
            f1.add_arc('set3', 'set0', (letter), ())
            f1.add_arc('set4', 'set0', (letter), ())
            f1.add_arc('set5', 'set0', (letter), ())
            f1.add_arc('set6', 'set0', (letter), ())

            f1.add_arc('set0', 'set0', (letter), ())




        # f1.add_arc('next', 'next', (letter), ('0'))



    return f1

    # The stub code above converts all letters except the first into '0'.
    # How can you change it to do the right conversion?

def truncate_to_three_digits():
    """
    Create an FST that will truncate a soundex string to three digits
    """

    # Ok so now let's do the second FST, the one that will truncate
    # the number of digits to 3
    f2 = FST('soundex-truncate')

    # Indicate initial and final states
    f2.add_state('1')
    f2.add_state('2')
    f2.add_state('3')
    f2.add_state('4')
    f2.initial_state = '1'
    f2.set_final('1')
    f2.set_final('2')
    f2.set_final('3')
    f2.set_final('4')

    # Add the arcs
    for letter in string.letters:
        f2.add_arc('1', '1', (letter), (letter))
        f2.add_arc('2', '3', (letter), (letter))
        f2.add_arc('3', '4', (letter), (letter))
        f2.add_arc('4', '4', (letter), ())



    for n in range(10):
        f2.add_arc('1', '2', (str(n)), (str(n)))
        f2.add_arc('2', '3', (str(n)), (str(n)))
        f2.add_arc('3', '4', (str(n)), (str(n)))
        f2.add_arc('4', '4', (str(n)), ())

    #f2.add_arc('2', '4', (), ())
    #f2.add_arc('3', '4', (), ())


    return f2

    # The above stub code doesn't do any truncating at all -- it passes letter and number input through
    # what changes would make it truncate digits to 3?

def add_zero_padding():
    # Now, the third fst - the zero-padding fst
    f3 = FST('soundex-padzero')

    f3.add_state('1')
    f3.add_state('1a')
    f3.add_state('1b')
    f3.add_state('2')

    ## my add
    f3.add_state('1.1')
    f3.add_state('1.2')
    f3.add_state('1.3')
    
    f3.initial_state = '1'
    f3.set_final('2')

    ## my add
    f3.set_final('1.3')



    for letter in string.letters:
        f3.add_arc('1', '1', (letter), (letter))


    for number in xrange(10):
        f3.add_arc('1', '1.1', (str(number)), (str(number)))
        f3.add_arc('1.1', '1.2', (str(number)), (str(number)))
        f3.add_arc('1.2', '1.3', (str(number)), (str(number)))
    
    f3.add_arc('1', '1a', (), ('0'))
    f3.add_arc('1a', '1b', (), ('0'))
    f3.add_arc('1b', '2', (), ('0'))

    f3.add_arc('1.1', '1b', (), ('0'))
    f3.add_arc('1.2', '2', (), ('0'))






    return f3

    # The above code adds zeroes but doesn't have any padding logic. Add some!

if __name__ == '__main__':
    user_input = raw_input().strip()
    f1 = letters_to_numbers()
    f2 = truncate_to_three_digits()
    f3 = add_zero_padding()

    if user_input:
        print("%s -> %s" % (user_input, composechars(tuple(user_input), f1, f2, f3)))
