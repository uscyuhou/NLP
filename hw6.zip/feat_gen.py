#!/bin/python
import nltk
import codecs

from nltk.corpus import wordnet as wn
from nltk.corpus import stopwords


def morphy_stem(word):
    """
    Simple stemmer
    """
    stem = wn.morphy(word)
    if stem:
        return stem.lower()
    else:
        return word.lower()

feature = []
featureL = []

def preprocess_corpus(train_sents):
    """Use the sentences to do whatever preprocessing you think is suitable,
    such as counts, keeping track of rare features/words to remove, matches to lexicons,
    loading files, and so on. Avoid doing any of this in token2features, since
    that will be called on every token of every sentence.

    Of course, this is an optional function.

    Note that you can also call token2features here to aggregate feature counts, etc.
    """
    # corpusList = ['architecture.museum','automovie.make','automotive.model','award.award','basw.events.festival_series','bigdict','book.newspaper','broadcast.tv_channel','business.brand','business.consumer_company','business.consumer_product','business.sponsor',
    #               'cap.10000','firstname.1000','lastname.1000']

    # corpusList = ['location','product','business.brand','sports.sports_team','tv.tv_program',]
    # corpusList = ['location']

    corpusList = ['architecture.museum', 'automotive.make', 'automotive.model', 'award.award',
                  'base.events.festival_series', 'bigdict', 'book.newspaper', 'broadcast.tv_channel', 'business.brand',
                  'business.consumer_company', 'business.consumer_product', 'business.sponsor',
                  'cap.1000', 'cvg.cvg_developer', 'cvg.cvg_platform', 'dictionaries.conf', 'education.university',
                  'english.stop', 'firstname.1000', 'government.government_agency', 'internet.website', 'lastname.1000',
                  'location', 'location.country', 'people.family_name', 'people.person', 'people.person.lastnames',
                  'product',
                  'sports.sports_league', 'sports.sports_team', 'time.holiday', 'time.recurring_event',
                  'transportation.road', 'tv.tv_network', 'tv.tv_program', 'venture_capital.venture_funded_company',
                  'venues']

    # preprocess_corpus.feature = {}
    # ### lalala
    preprocess_corpus.feature = []





    # for element in corpusList :
    #     preprocess_corpus.feature[element] = []
    #
    #     f = codecs.open("data/lexicon/"+element, "r",'utf-8')
    #
    #     for line in f:
    #         # entity = tuple(line.strip().split(" "))   ## you gai dong
    #         entity = line
    #         preprocess_corpus.feature[element].append(entity)
    #     # feature[element] = set(feature[element])
    #     f.close()
    #### lalala
    for i in range(len(corpusList)):
        listtemp = []
        listtempL = []
        f = codecs.open("data/lexicon/" + corpusList[i], "r", 'utf-8')

        for line in f:
            entity = line.strip().split(" ")
            listtempL.append(entity[0])
            for i in range(1,len(entity)):
                listtemp.append(entity[i])
        f.close()
        # preprocess_corpus.feature.append(set(listtemp))
        feature.append(set(listtemp))
        featureL.append(set(listtempL))




    # print preprocess_corpus.feature


    # preprocess Part of speach!!!
    preprocess_corpus.POSfeature = {}

    for sent in train_sents:
        # print sent
        text = sent
        POSresult = nltk.pos_tag(text)
        preprocess_corpus.POSfeature[' '.join(sent)]=POSresult
    preprocess_corpus.sentsSet = set(preprocess_corpus.POSfeature.keys())


    pass

def token2features(sent, i, add_neighs = True):
    """Compute the features of a token.

    All the features are boolean, i.e. they appear or they do not. For the token,
    you have to return a set of strings that represent the features that *fire*
    for the token. See the code below.

    The token is at position i, and the rest of the sentence is provided as well.
    Try to make this efficient, since it is called on every token.

    One thing to note is that it is only called once per token, i.e. we do not call
    this function in the inner loops of training. So if your training is slow, it's
    not because of how long it's taking to run this code. That said, if your number
    of features is quite large, that will cause slowdowns for sure.

    add_neighs is a parameter that allows us to use this function itself in order to
    recursively add the same features, as computed for the neighbors. Of course, we do
    not want to recurse on the neighbors again, and then it is set to False (see code).
    """
    ftrs = []
    # bias
    ftrs.append("BIAS")
    # position features
    if i == 0:
        ftrs.append("SENT_BEGIN")
    if i == len(sent)-1:
        ftrs.append("SENT_END")

    # the word itself
    word = unicode(sent[i])
    ftrs.append("WORD=" + word)
    ftrs.append("LCASE=" + word.lower())
    # some features of the word
    if word.isalnum():
        ftrs.append("IS_ALNUM")
    if word.isnumeric():
        ftrs.append("IS_NUMERIC")
    if word.isdigit():
        ftrs.append("IS_DIGIT")
    if word.isupper():
        ftrs.append("IS_UPPER")
    if word.islower():
        ftrs.append("IS_LOWER")

    #
    #0 feature 0:
    if word[0].isupper():
        ftrs.append("IS_FIRSTUPPER")

    stop_words = set(stopwords.words('english'))
    if word in stop_words:
        ftrs.append("IS_STOPWORDS")
    if '-' in word:
        ftrs.append('IS_-')
    if '#' in word:
        ftrs.append('IS_#')
    if "'" in word:
        ftrs.append("IS_'")
    #



    ## word entity recognition infromation:::::

    ## word is location or person???
    found = False

    # #1
    # for element in preprocess_corpus.feature:
    #     # print preprocess_corpus.feature[element]
    #     for key in preprocess_corpus.feature[element]:
    #
    #         if word in key:
    #             #print "1",element,word,key
    #             location = key.index(word)
    #             if location == 0:
    #                 ftrs.append("B_"+str.upper(element))
    #                 found = True
    #                 break
    #             else:
    #                 ftrs.append("I_" + str.upper(element))
    #                 found = True
    #                 break

    # 1 other version
    # print type(preprocess_corpus.feature.keys())

    #
    for element in range(len(feature)):
        # print preprocess_corpus.feature[element]
        # for i in range(len(preprocess_corpus.feature[element])):
        # for key in feature[element]:

            # wordcase = word.upper()
            # print word

            if word in feature[element]:
                # print "1",element,word,key
                ftrs.append("IS_" + "I-FILE"+ str(element))
                # break
    for element in range(len(featureL)):
        # print preprocess_corpus.feature[element]
        # for i in range(len(preprocess_corpus.feature[element])):
        # for key in feature[element]:

            # wordcase = word.upper()
            # print word

            if word in featureL[element]:
                # print "1",element,word,key
                ftrs.append("IS_" + "B-FILE"+ str(element))
                # break
    # #
    #
    # ## morphy method, to see if this word is original shape, or it changed its shape???
    #
    #2
    if word == morphy_stem(word):
        ftrs.append("SAME=True")
    else:
        ftrs.append("SAME=False")

    # #2 other version
    # ftrs.append("STEM="+morphy_stem(word))

    ## word Part of Speech information:
    ## BAD NEWS BAD NEWS BAD NEWS is that this will process many times!!!!!

    #
    # import nltk
    # text = sent
    # POSresult = nltk.pos_tag(text)
    # ftrs.append('POS_'+POSresult[i][1])


    ## try to process: here are new code for process

    #3
    if ' '.join(sent) in preprocess_corpus.sentsSet:
        ftrs.append('POS_' + preprocess_corpus.POSfeature[' '.join(sent)][i][1])
    else:
        text = sent
        POSresult = nltk.pos_tag(text)
        ftrs.append('POS_'+POSresult[i][1])



    # previous/next word feats
    if add_neighs:
        if i > 0:
            for pf in token2features(sent, i-1, add_neighs = False):
                ftrs.append("PREV_" + pf)
        if i < len(sent)-1:
            for pf in token2features(sent, i+1, add_neighs = False):
                ftrs.append("NEXT_" + pf)

    # return it!
    return ftrs

if __name__ == "__main__":
    sents = [
    [ "I", "love", "food" ]
    ]
    preprocess_corpus(sents)
    for sent in sents:
        for i in xrange(len(sent)):
            print sent[i], ":", token2features(sent, i)
