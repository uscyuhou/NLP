import numpy as np
from numpy import random

def run_viterbi(emission_scores, trans_scores, start_scores, end_scores):
    """Run the Viterbi algorithm.

    N - number of tokens (length of sentence)
    L - number of labels

    As an input, you are given:
    - Emission scores, as an NxL array
    - Transition scores (Yp -> Yc), as an LxL array
    - Start transition scores (S -> Y), as an Lx1 array
    - End transition scores (Y -> E), as an Lx1 array

    You have to return a tuple (s,y), where:
    - s is the score of the best sequence
    - y is a size N array of integers representing the best sequence.
    """
    L = start_scores.shape[0]
    assert end_scores.shape[0] == L
    assert trans_scores.shape[0] == L
    assert trans_scores.shape[1] == L
    assert emission_scores.shape[1] == L
    N = emission_scores.shape[0]

    # print type(L)
    # print type(N)
    # print emission_scores
    # print trans_scores
    # print start_scores
    # print start_scores[0]
    # print end_scores

    # main part:
    # print "number of N: ",N
    # print "number of L: ",L
    manipulateViterbi = np.zeros((L, N),dtype={'names':['col1', 'col2'], 'formats':['f8','i4']})
    #  = np.array()
    # manipulateViterbi = np.zeros((L,N))
    # print "1",manipulateViterbi
    l1 = [float("-inf"),0]
    t1 = tuple(l1)
    # manipulateViterbi = [[t1 for i in range(N)] for j in range(L)]
    # manipulateViterbi = np.array(manipulateViterbi)
    # print "2",manipulateViterbi

    for i in range(L):
        for j in range(N):
            manipulateViterbi[i][j] = t1
    # print "3", manipulateViterbi




    # print manipulateViterbi[0][0]
    ## set up the start states:

    for i in range(L):
        # manipulateViterbi[i][0][0] = 0.0
        manipulateViterbi[i][0][0] = start_scores[i] + emission_scores[0][i]

    # print manipulateViterbi


    # ## set the middle states:
    # if N ==1:
    #     ## emission for the last one:
    #     for i in range(L):
    #         manipulateViterbi[i][N - 1][0] = manipulateViterbi[i][N - 1][0] + emission_scores[N - 1][i]


    for i in range(1,N):
        for j in range(L):
            for k in range(L):
                # print i,j,k
                # print manipulateViterbi
                # print manipulateViterbi[i][j][0]


                #?????????????
                temple = manipulateViterbi[k][i-1][0]+trans_scores[k][j]+emission_scores[i][j]

                # print "1",temple
                # print "2",manipulateViterbi[j][i][0]
                if temple > manipulateViterbi[j][i][0]:
                    manipulateViterbi[j][i][0] = temple
                    manipulateViterbi[j][i][1] = k



    # print manipulateViterbi




    ## set the final states:
    for i in range(L):
        manipulateViterbi[i][N - 1][0] = manipulateViterbi[i][N - 1][0]+end_scores[i]


    # print manipulateViterbi



    y = []
    # for i in xrange(N):
    #     # stupid sequence
    #     y.append(i % L)
    # # score set to 0




    templeScore=float("-inf")
    location = 0
    for i in range(L):
        # print manipulateViterbi[i][N-1][0],"bijiao:",templeScore
        if manipulateViterbi[i][N-1][0] >templeScore:
            # print '1'
            templeScore = manipulateViterbi[i][N-1][0]
            location=i
    y.append(location)
    value = templeScore



    for i in xrange(N-1,0,-1):
        location = manipulateViterbi[location][i][1]
        y.append(location)

    y.reverse()

    # print y
    # print value
    return (value, y)
