#!/usr/bin/env python
from collections import defaultdict
from csv import DictReader, DictWriter

import nltk
import codecs
import sys
from nltk.corpus import wordnet as wn
from nltk.tokenize import TreebankWordTokenizer

# my code for n-grams
from nltk.util import ngrams

#from sklearn.feature_extraction.text import CountVectorizer
from nltk.text import TextCollection
from nltk.corpus import stopwords
from string import punctuation
from nltk.sentiment.vader import SentimentIntensityAnalyzer

SENTIMENT = SentimentIntensityAnalyzer()

kTOKENIZER = TreebankWordTokenizer()


def morphy_stem(word):
    """
    Simple stemmer
    """
    stem = wn.morphy(word)
    if stem:
        return stem.lower()
    else:
        return word.lower()



# my code for n-grams # The max number can only be 4
def word_grams(words, min, max):
    s = []
    for n in range(min, max):
        for ngram in ngrams(words, n):
            s.append(' '.join(str(i) for i in ngram))
    return s

class FeatureExtractor:

    def __init__(self):
        """
        You may want to add code here
        """
        #source = corpus
        sss=""
        pos=""
        neg=""
        # with open("Christopher Marlowe.txt",'r') as f:
        #     sss=f.read()
        # with open("positive.txt",'r') as f:
        #     pos=f.read()
        # with open("negative.txt",'r') as f:
        #     neg=f.read()
        self.pos=pos
        self.neg=neg
        self.TFIDF = TextCollection(sss)

        #nltk.corpus.gutenberg.words('shakespeare-hamlet.txt')


        #None

    def remove_stopwords(self,word_list):
        processed_word_list = []
        for word in word_list:
            #word = word.lower()  # change them into lower cases
            if word not in stopwords.words("english") and word not in punctuation:
                processed_word_list.append(word)
            if word not in punctuation:
                processed_word_list.append(word)
            # if word not in punctuation:
            #     processed_word_list.append(word)
        return processed_word_list

    def features(self, text):
        ss = SENTIMENT.polarity_scores(text)
        kkk=kTOKENIZER.tokenize(text)
        spl=text.split(" ")
        tokenizeText=self.remove_stopwords(kkk)
        postext=nltk.pos_tag(kkk)
        # print text
        # print kkk
        # print postext


        # # deal with postext, delete the duplicate elements:
        # temp=""
        # dup=[]
        # for index in range(len(postext)-1):
        #     temp=postext[index][0]
        #     if temp==postext[index+1][0]:
        #         dup.append(index+1)
        # postext=[postext[i] for i in range(0, len(postext)) if i not in dup]

        d = defaultdict(int)

        if spl[-1]=='':
            d["empty"]=1
        else:
            d["empty"]=0

        for ii in tokenizeText:
            # count the number of a word
            d[morphy_stem(ii)] += 1

            # count the tf of a word
            d[ii + "_tf"] = self.TFIDF.tf(ii, text)

            # if morphy_stem(ii) in self.pos:
            #     d[morphy_stem(ii)+"_pos"] +=1
            # if morphy_stem(ii) in self.neg:
            #     d[morphy_stem(ii)+"_neg"] +=1

            # count the tf_idf of a word
            # d[ii + "_tf_idf"] = self.TFIDF.tf_idf(ii, text)



        # for ii in kkk:
        #     d[ii + "_tf_idf"] = self.TFIDF.tf_idf(ii,text)

        # count the sentiment probability
        for key in ['pos','neg']:
            d[key+"_sentiment"]=ss[key]

        # count the pos number
        for pos in postext:
            for test in ["LS","JJR","JJS","RBP","RBS","NNP","PDT","UH","VBP","FW"]:
                if pos[1] == test:
                    if pos[1] + "_pos" not in d.keys():
                        d[pos[1] + "_pos"]=1
                    else:
                        d[pos[1] + "_pos"] = d[pos[1] + "_pos"] + 1


        # ## count the pos frequency:
        # d_pos = {}
        # for pos in postext:
        #     if pos[1] + "_pos" not in d_pos.keys():
        #         d_pos[pos[1] + "_pos"]=1
        #     else:
        #         d_pos[pos[1] + "_pos"] = d_pos[pos[1] + "_pos"] + 1
        # print d_pos
        # total_number=0
        # for key in d_pos.keys():
        #     total_number=total_number+d_pos[key]
        # print total_number
        # for key in d_pos.keys():
        #     print float(d_pos[key])/float(total_number)
        #     d[key+"_pos_frequency"] = float(d_pos[key])/float(total_number)



        # # 2-gram
        for index in range(len(postext)-1):
            # PRRMD = he should, MDPRP = should I, PDTIN= all of both of, WPPOS= what 's, PRP$NN= your book(s), TODT= to a,TOVBG= to doing,VBVBN= have done, EXVB= there be, POSDT='s the, RBVB adv verb, WRBTO= how to, WRBJJ= how adj
            for test in ["PRPMD","MDPRP","PDTIN","PDTNNS","WPPOS","PRP$NN","PRP$NNS","TODT","TOVBG","VBVBN","EXVB","POSDT","RBVB","WRBTO","WRBJJ"]:
                if postext[index][1] + postext[index+1][1] == test:
                    if postext[index][1] + postext[index+1][1] + "_pos" not in d:
                        d[postext[index][1] + postext[index+1][1] + "_pos"] = 1
                    else:
                        d[postext[index][1] + postext[index+1][1] + "_pos"] = d[postext[index][1] + postext[index+1][1] + "_pos"] + 1



        # # ## count the pos frequency:
        # d_2_pos = {}
        # for index in range(len(postext)-1):
        #     for test in ["PRPMD","MDPRP","PDTIN","PDTNNS","WPPOS","PRP$NN","PRP$NNS","TOPRP$","TODT","TOVBG","VBVBN","EXVB","POSDT","RBVB","WRBTO","WRBJJ"]:
        #         if postext[index][1] + postext[index+1][1] == test:
        #             if postext[index][1] + postext[index+1][1] + "_pos" not in d_2_pos:
        #                 d_2_pos[postext[index][1] + postext[index+1][1] + "_pos"] = 1
        #             else:
        #                 d_2_pos[postext[index][1] + postext[index+1][1] + "_pos"] += 1
        #
        # total_number=len(postext)-1
        # # for key in d_2_pos.keys():
        # #     total_number=total_number+d_2_pos[key]
        # for key in d_2_pos.keys():
        #
        #     d[key+"_pos_frequency"] = float(d_2_pos[key])/float(total_number)
        #

        # count the n-grams
        #My code for n-grams
        for ii in word_grams(text.split(' '),min=2, max=4):
            d[ii] += 1

            d[ii + "_tf"] += self.TFIDF.tf(ii, text)

        #d["_length_"] = len(text)
        d["__length__"] = len("".join(text.split(' ')))


        for word in ['should','shall','can','would','cannot','thee']:
            if word in kkk:
                d[word+"_location"] = float(kkk.index(word))/float(len(kkk))
                d[word] += 1
            else:
                d[word + "_location"] = 0
                d[word] = 0


        # for word in ["'st",'*','gay','still',"'d","ornament"]:
        #     if word in text:
        #         d[word] += 1
        #         # d[word] *= 5


        for word in ['my love','thou art']:
            if word in word_grams(text.split(' '),min=2, max=3):
                #d[word+"_location"] = float(word_grams(text.split(' '),min=2, max=3).index(word))/float(len(word_grams(text.split(' '),min=2, max=3)))
                d[word] += 1
            # else:
            #     d[word + "_location"] = 0
            #     # d[word] = 0

        # for word in punctuation:
        #     if word in kkk:
        #         #d[word+"_location"] = float(kkk.index(word))/float(len(kkk))
        #         d["punctuation"] +=1
        #         #d[word+"_whether"] = 1

        # for test in ['.',"?"]:
        #     for word in kkk:
        #         if word == test:
        #             d[word+"_location"] = float(kkk.index(word))/float(len(kkk))
        #             break
        #
        for word in ['*',"'st","'d","ornament"]:
            if word in kkk:
                d[word + "_whether"] =1
            else:
                d[word + "_whether"] = 0
        # #
        for word in ['Thou','All',"*"]:
            if word == kkk[0]:
                d[word+"_initial"] = 1
            else:
                d[word+"_initial"] = 0

        #
        # #
        # for word in ['RBS']:
        #     if postext[-1][0] in punctuation:
        #         print postext[-1][0]
        #         if word == postext[-2][1]:
        #             d[word+"_end"] = 1
        #         else:
        #             d[word + "_end"] = 0
        #     else:
        #         if word == postext[-1][1]:
        #             d[word+"_end"] = 1
        #         else:
        #             d[word + "_end"] = 0


        for word in ['rehearse','erred',"'d",'deeds','conspire','ire','end','ing','ight','ide']:
            if kkk[-1] in punctuation:

                if word in kkk[-2]:
                    #print kkk[-2]
                    d[word+"_end"] = 1
                # else:
                #     d[word + "_end"] = 0
            else:
                if word in kkk[-1]:

                    d[word+"_end"] = 1
                # else:
                #     d[word + "_end"] = 0



        # for word in ['MD']:
        #     for pos in postext:
        #         if word == pos[1]:
        #             d[word] += 1



        return d


reader = codecs.getreader('utf8')
writer = codecs.getwriter('utf8')


def prepfile(fh, code):
  if type(fh) is str:
    fh = open(fh, code)
  ret = gzip.open(fh.name, code if code.endswith("t") else code+"t") if fh.name.endswith(".gz") else fh
  if sys.version_info[0] == 2:
    if code.startswith('r'):
      ret = reader(fh)
    elif code.startswith('w'):
      ret = writer(fh)
    else:
      sys.stderr.write("I didn't understand code "+code+"\n")
      sys.exit(1)
  return ret

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument("--trainfile", "-i", nargs='?', type=argparse.FileType('r'), default=sys.stdin, help="input train file")
    parser.add_argument("--testfile", "-t", nargs='?', type=argparse.FileType('r'), default=None, help="input test file")
    parser.add_argument("--outfile", "-o", nargs='?', type=argparse.FileType('w'), default=sys.stdout, help="output file")
    parser.add_argument('--subsample', type=float, default=1.0,
                        help='subsample this fraction of total')
    args = parser.parse_args()
    trainfile = prepfile(args.trainfile, 'r')
    if args.testfile is not None:
        testfile = prepfile(args.testfile, 'r')
    else:
        testfile = None
    outfile = prepfile(args.outfile, 'w')

    # Create feature extractor (you may want to modify this)
    ## I added the corpus = something
    #fe = FeatureExtractor(corpus=trainfile)

    fe = FeatureExtractor()

    # Read in training data
    train = DictReader(trainfile, delimiter='\t')
    # for ii in train:
    #     print ii['text']
    # Split off dev section
    dev_train = []
    dev_test = []
    full_train = []

    for ii in train:
        if args.subsample < 1.0 and int(ii['id']) % 100 > 100 * args.subsample:
            continue
        feat = fe.features(ii['text'])
        if int(ii['id']) % 5 == 0:
            dev_test.append((feat, ii['cat']))
        else:
            dev_train.append((feat, ii['cat']))
        full_train.append((feat, ii['cat']))
    #print dev_test
    # Train a classifier
    sys.stderr.write("Training classifier ...\n")
    classifier = nltk.classify.NaiveBayesClassifier.train(dev_train)



    right = 0
    total = len(dev_test)
    for ii in dev_test:
        prediction = classifier.classify(ii[0])
        if prediction == ii[1]:
            right += 1
        # else:
        #     print ii[0]
    sys.stderr.write("Accuracy on dev: %f\n" % (float(right) / float(total)))

    if testfile is None:
        sys.stderr.write("No test file passed; stopping.\n")
    else:
        # Retrain on all data
        classifier = nltk.classify.NaiveBayesClassifier.train(dev_train + dev_test)

        # Read in test section
        test = {}
        for ii in DictReader(testfile, delimiter='\t'):
            test[ii['id']] = classifier.classify(fe.features(ii['text']))

        # Write predictions
        o = DictWriter(outfile, ['id', 'pred'])
        o.writeheader()
        for ii in sorted(test):
            o.writerow({'id': ii, 'pred': test[ii]})
